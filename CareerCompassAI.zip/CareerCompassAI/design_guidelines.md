# AI-Powered Career Assistant - Design Guidelines

## Design Approach

**Selected Approach:** Design System (Modern Professional SaaS)

**Reference Inspiration:** LinkedIn's professional aesthetic + Indeed's job listing clarity + Notion's clean data presentation

**Design Principles:**
- Professional credibility with approachable warmth
- Information clarity over visual complexity
- Scannable, card-based content organization
- Trust-building through clean, structured layouts

## Typography

**Font Stack:**
- Primary: Inter (Google Fonts) - headings, UI elements, body text
- Accent: No secondary font needed - Inter covers all uses

**Hierarchy:**
- H1: text-4xl font-bold (Hero headlines, page titles)
- H2: text-3xl font-semibold (Section headers)
- H3: text-xl font-semibold (Card titles, subsection headers)
- Body: text-base font-normal (Descriptions, content)
- Small: text-sm font-medium (Labels, metadata, tags)

## Layout System

**Spacing Primitives:** Tailwind units of 2, 4, 6, and 8 (e.g., p-4, gap-6, mt-8, mb-2)

**Container Strategy:**
- Dashboard/App pages: max-w-7xl mx-auto px-6
- Marketing/Landing: Full-width sections with max-w-6xl inner containers
- Forms: max-w-2xl for optimal readability

**Grid Patterns:**
- Job listings: 1 column mobile, 2 columns desktop (md:grid-cols-2)
- Skill cards: 2-3 columns responsive (grid-cols-2 lg:grid-cols-3)
- Profile sections: Single column with clear vertical flow

## Component Library

### Navigation
- Top navigation bar with logo, main links, user profile dropdown
- Sticky header on scroll for easy access
- Mobile: Hamburger menu with slide-out drawer

### Job Cards
- Clean white cards with subtle shadow (shadow-sm hover:shadow-md transition)
- Structure: Company logo (top-left) + Job title + Company name + Location + Key requirements (bulleted list) + Match score badge + "View Details" button
- Match score: Prominent percentage badge (bg-gradient or solid) in top-right
- Spacing: p-6 with gap-4 between elements

### Profile Input Forms
- Multi-step wizard layout OR single-page sectioned form
- Clear section headers with icons
- Input fields: Generous padding (p-3), rounded corners (rounded-lg), subtle borders
- Tag inputs for skills: Pill-style tags with remove 'x' button
- Textarea for experience/bio: min-h-32

### Dashboard Layout
- Left sidebar navigation (fixed on desktop, drawer on mobile)
- Main content area: Dashboard cards showing stats (Jobs matched, Skills to learn, Profile strength)
- Card grid for quick actions and recommendations

### AI Feedback Components
- Collapsible panels for resume feedback sections
- Color-coded feedback: Success (green accent), Warning (amber accent), Info (blue accent)
- Bullet points with check/info icons
- "Regenerate feedback" button with loading state

### Skill Recommendations
- Horizontal scrollable card row OR grid layout
- Each card: Skill icon/emoji + Skill name + "Why this matters" snippet + "Start learning" CTA
- Trending indicator badge for hot skills

### Buttons
- Primary: Solid fill, rounded-lg, px-6 py-3, font-medium
- Secondary: Outline style with border-2
- Text buttons: No background, subtle hover underline
- Disabled state: Reduced opacity (opacity-50)

## Landing Page Structure

**Hero Section (80vh):**
- Split layout: Left side (60%) - Headline + Subheadline + CTA buttons + Trust indicator ("10,000+ careers accelerated")
- Right side (40%) - Hero image showing dashboard preview or professional ascending career visualization
- Background: Subtle gradient or clean solid

**Features Section:**
- 3-column grid (stacks on mobile)
- Icon + Feature title + Description for: AI Job Matching, Skill Recommendations, Resume Feedback
- Icons from Heroicons

**How It Works:**
- 3-step process cards (numbered badges)
- Horizontal flow on desktop, vertical on mobile

**Social Proof:**
- 2-column testimonial cards with user photo + quote + name + current role
- Statistics bar: Jobs matched, Skills recommended, Users helped

**CTA Section:**
- Centered, generous padding (py-20)
- Headline + Supporting text + Primary CTA button

**Footer:**
- 4-column layout: About, Features, Resources, Contact
- Newsletter signup form
- Social links + Copyright

## Images

**Hero Image:** Dashboard preview mockup showing the job matching interface with blurred sample data - positioned right side of hero split layout, image should have subtle shadow/border treatment

**Feature Icons:** Use Heroicons for all feature/UI icons (briefcase, chart-bar, document-text, etc.)

**Testimonial Photos:** Professional headshots, circular avatars (w-12 h-12)

**Profile Placeholders:** Generic avatar icons for new users

## Animations

**Minimal Motion:**
- Card hover: subtle lift with shadow transition (transition-shadow duration-200)
- Button hover: slight scale OR color shift (no elaborate effects)
- Page transitions: Simple fade-in for new content
- Loading states: Subtle spinner, no elaborate skeleton screens unless absolutely necessary

## Accessibility

- All interactive elements must have visible focus states (ring-2 ring-offset-2)
- Form inputs include labels with for/id attributes
- Color is not the only differentiator (use icons + text)
- Sufficient contrast ratios throughout