import { apiRequest } from "./queryClient";

export interface Profile {
  id: string;
  userId: string | null;
  name: string;
  email: string;
  title: string | null;
  experience: string | null;
  education: string | null;
  skills: string[] | null;
  interests: string[] | null;
  bio: string | null;
}

export interface Job {
  id: string;
  title: string;
  company: string;
  location: string;
  type: string;
  salary: string | null;
  description: string | null;
  requirements: string[] | null;
  skills: string[] | null;
  postedAt: string | null;
  matchScore?: number;
}

export interface Skill {
  id: string;
  name: string;
  category: string;
  description: string | null;
  trending: boolean | null;
}

export interface AISkillRecommendation {
  id: string;
  name: string;
  category: string;
  relevance: string;
  trending: boolean;
  reason: string;
}

export interface ResumeFeedbackItem {
  type: "success" | "warning" | "info";
  title: string;
  description: string;
}

export interface ResumeFeedbackSection {
  title: string;
  items: ResumeFeedbackItem[];
}

export interface DashboardStats {
  jobsMatched: number;
  skillsToLearn: number;
  profileStrength: number;
  applications: number;
}

export async function createProfile(profile: Omit<Profile, "id">): Promise<Profile> {
  const res = await apiRequest("POST", "/api/profile", profile);
  return res.json();
}

export async function updateProfile(id: string, profile: Partial<Profile>): Promise<Profile> {
  const res = await apiRequest("PATCH", `/api/profile/${id}`, profile);
  return res.json();
}

export async function getMatchedJobs(skills: string[], interests: string[]): Promise<Job[]> {
  const res = await apiRequest("POST", "/api/jobs/match", { skills, interests });
  return res.json();
}

export async function getRecommendedSkills(skills: string[], interests: string[]): Promise<Skill[]> {
  const res = await apiRequest("POST", "/api/skills/recommend", { skills, interests });
  return res.json();
}

export async function getAISkillRecommendations(
  skills: string[],
  interests: string[],
  experience?: string,
  targetRole?: string
): Promise<AISkillRecommendation[]> {
  const res = await apiRequest("POST", "/api/ai/skill-recommendations", { 
    skills, interests, experience, targetRole 
  });
  return res.json();
}

export async function analyzeResume(resumeText: string): Promise<ResumeFeedbackSection[]> {
  const res = await apiRequest("POST", "/api/ai/resume-feedback", { resumeText });
  return res.json();
}

export function getStatsQueryKey(skills: string[], interests: string[]) {
  const params = new URLSearchParams();
  if (skills.length) params.set("skills", skills.join(","));
  if (interests.length) params.set("interests", interests.join(","));
  return `/api/stats?${params.toString()}`;
}
