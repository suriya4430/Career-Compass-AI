import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Briefcase, Target, Lightbulb, TrendingUp, ArrowRight } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { StatsCard } from "@/components/dashboard/StatsCard";
import { JobCard } from "@/components/dashboard/JobCard";
import { SkillCard } from "@/components/dashboard/SkillCard";
import type { Profile, Job, Skill, DashboardStats } from "@/lib/api";

export default function Dashboard() {
  const { data: profile, isLoading: profileLoading } = useQuery<Profile | null>({
    queryKey: ["/api/profile"],
  });

  const userSkills = profile?.skills || [];
  const userInterests = profile?.interests || [];

  const { data: jobs = [], isLoading: jobsLoading } = useQuery<(Job & { matchScore: number })[]>({
    queryKey: ["/api/jobs/match"],
    queryFn: async () => {
      const res = await fetch("/api/jobs/match", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ skills: userSkills, interests: userInterests }),
      });
      return res.json();
    },
    enabled: !profileLoading,
  });

  const { data: skills = [], isLoading: skillsLoading } = useQuery<Skill[]>({
    queryKey: ["/api/skills/recommend"],
    queryFn: async () => {
      const res = await fetch("/api/skills/recommend", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ skills: userSkills, interests: userInterests }),
      });
      return res.json();
    },
    enabled: !profileLoading,
  });

  const profileStrength = Math.min(100, 
    (profile?.name ? 20 : 0) +
    (profile?.email ? 10 : 0) +
    (profile?.title ? 15 : 0) +
    ((profile?.skills?.length || 0) > 0 ? 25 : 0) +
    ((profile?.interests?.length || 0) > 0 ? 15 : 0) +
    (profile?.bio ? 15 : 0)
  );

  const topJobs = jobs.slice(0, 3);
  const topSkills = skills.slice(0, 4).map((s, i) => ({
    id: s.id,
    name: s.name,
    category: s.category,
    relevance: s.trending ? "Trending" : "Recommended",
    trending: s.trending || false,
    reason: s.description || "This skill will help advance your career.",
  }));

  const isLoading = profileLoading || jobsLoading || skillsLoading;

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold" data-testid="text-dashboard-title">
            Welcome back{profile?.name ? `, ${profile.name.split(' ')[0]}` : ''}!
          </h1>
          <p className="text-muted-foreground">Here's your career progress at a glance.</p>
        </div>
        <Link href="/profile">
          <Button className="gap-2" data-testid="button-update-profile">
            Update Profile
            <ArrowRight className="w-4 h-4" />
          </Button>
        </Link>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {isLoading ? (
          <>
            <Skeleton className="h-32" />
            <Skeleton className="h-32" />
            <Skeleton className="h-32" />
            <Skeleton className="h-32" />
          </>
        ) : (
          <>
            <StatsCard
              title="Jobs Matched"
              value={jobs.length}
              description="Based on your profile"
              icon={Briefcase}
              color="chart-1"
            />
            <StatsCard
              title="Profile Strength"
              value={`${profileStrength}%`}
              description={profileStrength < 100 ? "Complete your profile" : "Profile complete"}
              icon={Target}
              color="chart-2"
            />
            <StatsCard
              title="Skills to Learn"
              value={skills.length}
              description="Recommended for you"
              icon={Lightbulb}
              color="chart-3"
            />
            <StatsCard
              title="Applications"
              value={0}
              description="This month"
              icon={TrendingUp}
              color="chart-4"
            />
          </>
        )}
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-4">
          <CardTitle className="text-lg">Profile Completion</CardTitle>
          <span className="text-sm text-muted-foreground">{profileStrength}% Complete</span>
        </CardHeader>
        <CardContent>
          <Progress value={profileStrength} className="h-2" />
          <div className="mt-4 grid sm:grid-cols-3 gap-4 text-sm">
            <div className="flex items-center gap-2">
              <div className={`w-2 h-2 rounded-full ${profile?.name ? 'bg-chart-2' : 'bg-muted'}`} />
              <span className="text-muted-foreground">Basic Info</span>
            </div>
            <div className="flex items-center gap-2">
              <div className={`w-2 h-2 rounded-full ${(profile?.skills?.length || 0) > 0 ? 'bg-chart-2' : 'bg-muted'}`} />
              <span className="text-muted-foreground">Skills Added</span>
            </div>
            <div className="flex items-center gap-2">
              <div className={`w-2 h-2 rounded-full ${profile?.bio ? 'bg-chart-2' : 'bg-muted'}`} />
              <span className="text-muted-foreground">Bio Complete</span>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold">Top Job Matches</h2>
            <Link href="/jobs">
              <Button variant="ghost" size="sm" className="gap-1" data-testid="link-view-all-jobs">
                View All
                <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
          </div>
          {isLoading ? (
            <div className="space-y-4">
              <Skeleton className="h-40" />
              <Skeleton className="h-40" />
              <Skeleton className="h-40" />
            </div>
          ) : topJobs.length > 0 ? (
            <div className="space-y-4">
              {topJobs.map((job) => (
                <JobCard 
                  key={job.id} 
                  job={{
                    id: job.id,
                    title: job.title,
                    company: job.company,
                    location: job.location,
                    type: job.type,
                    salary: job.salary || "Competitive",
                    matchScore: job.matchScore,
                    skills: job.skills || [],
                    postedAt: job.postedAt || "Recently",
                  }} 
                  onViewDetails={(j) => console.log("View job:", j.title)} 
                />
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="p-8 text-center">
                <p className="text-muted-foreground">
                  Add skills to your profile to see job matches.
                </p>
                <Link href="/profile">
                  <Button variant="outline" className="mt-4">Complete Profile</Button>
                </Link>
              </CardContent>
            </Card>
          )}
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold">Skills to Learn</h2>
            <Link href="/skills">
              <Button variant="ghost" size="sm" className="gap-1" data-testid="link-view-all-skills">
                View All
                <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
          </div>
          {isLoading ? (
            <div className="space-y-3">
              <Skeleton className="h-28" />
              <Skeleton className="h-28" />
              <Skeleton className="h-28" />
            </div>
          ) : topSkills.length > 0 ? (
            <div className="space-y-3">
              {topSkills.map((skill) => (
                <SkillCard 
                  key={skill.id} 
                  skill={skill} 
                  onLearnMore={(s) => console.log("Learn:", s.name)} 
                />
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="p-6 text-center">
                <p className="text-sm text-muted-foreground">
                  Update your profile to get skill recommendations.
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
