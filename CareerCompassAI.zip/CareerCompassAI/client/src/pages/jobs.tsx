import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Search, Filter, SlidersHorizontal } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { JobCard } from "@/components/dashboard/JobCard";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import type { Profile, Job } from "@/lib/api";

export default function Jobs() {
  const [searchQuery, setSearchQuery] = useState("");
  const [sortBy, setSortBy] = useState("match");
  const [filters, setFilters] = useState({
    remote: false,
    fullTime: true,
    contract: false,
    minMatch: 50,
  });

  const { data: profile } = useQuery<Profile | null>({
    queryKey: ["/api/profile"],
  });

  const userSkills = profile?.skills || [];
  const userInterests = profile?.interests || [];

  const { data: jobs = [], isLoading } = useQuery<(Job & { matchScore: number })[]>({
    queryKey: ["/api/jobs/match", userSkills, userInterests],
    queryFn: async () => {
      const res = await fetch("/api/jobs/match", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ skills: userSkills, interests: userInterests }),
      });
      return res.json();
    },
  });

  const filteredJobs = jobs
    .filter((job) => {
      if (searchQuery) {
        const query = searchQuery.toLowerCase();
        return (
          job.title.toLowerCase().includes(query) ||
          job.company.toLowerCase().includes(query) ||
          (job.skills || []).some((s) => s.toLowerCase().includes(query))
        );
      }
      return true;
    })
    .filter((job) => job.matchScore >= filters.minMatch)
    .filter((job) => {
      if (filters.remote && job.location.toLowerCase() !== "remote") return false;
      return true;
    })
    .sort((a, b) => {
      if (sortBy === "match") return b.matchScore - a.matchScore;
      return 0;
    });

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold" data-testid="text-jobs-title">Job Matches</h1>
        <p className="text-muted-foreground">Jobs tailored to your skills and interests.</p>
      </div>

      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search jobs, companies, or skills..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
            data-testid="input-search-jobs"
          />
        </div>
        <div className="flex gap-2">
          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="w-40" data-testid="select-sort-jobs">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="match">Best Match</SelectItem>
              <SelectItem value="recent">Most Recent</SelectItem>
              <SelectItem value="salary">Highest Salary</SelectItem>
            </SelectContent>
          </Select>
          
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="outline" className="gap-2" data-testid="button-filter-jobs">
                <SlidersHorizontal className="w-4 h-4" />
                Filters
              </Button>
            </SheetTrigger>
            <SheetContent>
              <SheetHeader>
                <SheetTitle>Filter Jobs</SheetTitle>
                <SheetDescription>
                  Narrow down your job search with filters.
                </SheetDescription>
              </SheetHeader>
              <div className="mt-6 space-y-6">
                <div className="space-y-4">
                  <Label>Job Type</Label>
                  <div className="space-y-3">
                    <div className="flex items-center gap-2">
                      <Checkbox
                        id="fullTime"
                        checked={filters.fullTime}
                        onCheckedChange={(checked) =>
                          setFilters((prev) => ({ ...prev, fullTime: !!checked }))
                        }
                      />
                      <Label htmlFor="fullTime" className="font-normal">Full-time</Label>
                    </div>
                    <div className="flex items-center gap-2">
                      <Checkbox
                        id="contract"
                        checked={filters.contract}
                        onCheckedChange={(checked) =>
                          setFilters((prev) => ({ ...prev, contract: !!checked }))
                        }
                      />
                      <Label htmlFor="contract" className="font-normal">Contract</Label>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <Label>Location</Label>
                  <div className="flex items-center gap-2">
                    <Checkbox
                      id="remote"
                      checked={filters.remote}
                      onCheckedChange={(checked) =>
                        setFilters((prev) => ({ ...prev, remote: !!checked }))
                      }
                    />
                    <Label htmlFor="remote" className="font-normal">Remote Only</Label>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <Label>Minimum Match Score</Label>
                  <Select
                    value={String(filters.minMatch)}
                    onValueChange={(value) =>
                      setFilters((prev) => ({ ...prev, minMatch: Number(value) }))
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="50">50%+</SelectItem>
                      <SelectItem value="60">60%+</SelectItem>
                      <SelectItem value="70">70%+</SelectItem>
                      <SelectItem value="80">80%+</SelectItem>
                      <SelectItem value="90">90%+</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>

      <div className="text-sm text-muted-foreground">
        Showing {filteredJobs.length} of {jobs.length} jobs
      </div>

      {isLoading ? (
        <div className="space-y-4">
          <Skeleton className="h-40" />
          <Skeleton className="h-40" />
          <Skeleton className="h-40" />
        </div>
      ) : (
        <div className="space-y-4">
          {filteredJobs.map((job) => (
            <JobCard
              key={job.id}
              job={{
                id: job.id,
                title: job.title,
                company: job.company,
                location: job.location,
                type: job.type,
                salary: job.salary || "Competitive",
                matchScore: job.matchScore,
                skills: job.skills || [],
                postedAt: job.postedAt || "Recently",
              }}
              onViewDetails={(j) => console.log("View job:", j.title)}
            />
          ))}
          
          {filteredJobs.length === 0 && (
            <div className="text-center py-12">
              <Filter className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-medium">No jobs found</h3>
              <p className="text-muted-foreground">Try adjusting your search or filters.</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
