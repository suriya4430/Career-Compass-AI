import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { CheckCircle2, AlertCircle, Info, RefreshCw, Sparkles, Upload, FileText } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { cn } from "@/lib/utils";
import { analyzeResume, type ResumeFeedbackSection } from "@/lib/api";

export default function Resume() {
  const [resumeText, setResumeText] = useState("");
  const [openSections, setOpenSections] = useState<string[]>([]);

  const analyzeMutation = useMutation({
    mutationFn: (text: string) => analyzeResume(text),
    onSuccess: (data) => {
      if (data.length > 0) {
        setOpenSections([data[0].title]);
      }
    },
  });

  const handleAnalyze = () => {
    if (resumeText.trim().length >= 50) {
      analyzeMutation.mutate(resumeText);
    }
  };

  const toggleSection = (title: string) => {
    setOpenSections(prev => 
      prev.includes(title) 
        ? prev.filter(t => t !== title)
        : [...prev, title]
    );
  };

  const getIcon = (type: "success" | "warning" | "info") => {
    switch (type) {
      case "success":
        return <CheckCircle2 className="w-4 h-4 text-chart-2 shrink-0" />;
      case "warning":
        return <AlertCircle className="w-4 h-4 text-chart-4 shrink-0" />;
      case "info":
        return <Info className="w-4 h-4 text-chart-1 shrink-0" />;
    }
  };

  const getBgColor = (type: "success" | "warning" | "info") => {
    switch (type) {
      case "success":
        return "bg-chart-2/10";
      case "warning":
        return "bg-chart-4/10";
      case "info":
        return "bg-chart-1/10";
    }
  };

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold" data-testid="text-resume-title">Resume Feedback</h1>
        <p className="text-muted-foreground">Get AI-powered suggestions to improve your resume.</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-primary" />
            AI Resume Analysis
          </CardTitle>
          <CardDescription>
            Paste your resume text below to get AI-powered suggestions for improvement.
            For best results, include your work experience, skills, education, and achievements.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Textarea
            placeholder="Paste your resume content here... Include your work experience, skills, education, and any other relevant information. Minimum 50 characters required."
            value={resumeText}
            onChange={(e) => setResumeText(e.target.value)}
            className="min-h-48"
            data-testid="textarea-resume"
          />
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex flex-wrap gap-2">
              <Button
                onClick={handleAnalyze}
                disabled={analyzeMutation.isPending || resumeText.trim().length < 50}
                className="gap-2"
                data-testid="button-analyze-resume"
              >
                {analyzeMutation.isPending ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    Analyze Resume
                  </>
                )}
              </Button>
              <Button variant="outline" className="gap-2" disabled data-testid="button-upload-resume">
                <Upload className="w-4 h-4" />
                Upload PDF (Coming Soon)
              </Button>
            </div>
            <span className="text-sm text-muted-foreground">
              {resumeText.length} characters {resumeText.length < 50 && "(minimum 50)"}
            </span>
          </div>
        </CardContent>
      </Card>

      {analyzeMutation.isError && (
        <Card className="border-destructive">
          <CardContent className="p-4">
            <p className="text-destructive flex items-center gap-2">
              <AlertCircle className="w-4 h-4" />
              Failed to analyze resume. Please try again.
            </p>
          </CardContent>
        </Card>
      )}

      {analyzeMutation.data && analyzeMutation.data.length > 0 && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <FileText className="w-5 h-5" />
              Analysis Results
            </h3>
            <Button
              variant="ghost"
              size="sm"
              className="gap-2"
              onClick={handleAnalyze}
              disabled={analyzeMutation.isPending}
              data-testid="button-regenerate-feedback"
            >
              <RefreshCw className={cn("w-4 h-4", analyzeMutation.isPending && "animate-spin")} />
              Regenerate
            </Button>
          </div>

          {analyzeMutation.data.map((section, sectionIndex) => (
            <Card key={sectionIndex} data-testid={`card-feedback-section-${sectionIndex}`}>
              <Collapsible
                open={openSections.includes(section.title)}
                onOpenChange={() => toggleSection(section.title)}
              >
                <CollapsibleTrigger asChild>
                  <CardHeader className="cursor-pointer hover-elevate">
                    <CardTitle className="text-base flex items-center justify-between">
                      {section.title}
                      <span className="text-sm font-normal text-muted-foreground">
                        {section.items.length} suggestions
                      </span>
                    </CardTitle>
                  </CardHeader>
                </CollapsibleTrigger>
                <CollapsibleContent>
                  <CardContent className="pt-0 space-y-3">
                    {section.items.map((item, itemIndex) => (
                      <div
                        key={itemIndex}
                        className={cn("p-3 rounded-md", getBgColor(item.type))}
                        data-testid={`feedback-item-${sectionIndex}-${itemIndex}`}
                      >
                        <div className="flex items-start gap-3">
                          {getIcon(item.type)}
                          <div>
                            <p className="font-medium text-sm">{item.title}</p>
                            <p className="text-sm text-muted-foreground mt-1">{item.description}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </CollapsibleContent>
              </Collapsible>
            </Card>
          ))}
        </div>
      )}

      {!analyzeMutation.data && !analyzeMutation.isPending && (
        <Card>
          <CardContent className="p-8 text-center">
            <FileText className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-medium mb-2">Ready to Improve Your Resume</h3>
            <p className="text-muted-foreground max-w-md mx-auto">
              Paste your resume content above and click "Analyze Resume" to get personalized 
              AI-powered feedback on how to make your resume stand out.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
