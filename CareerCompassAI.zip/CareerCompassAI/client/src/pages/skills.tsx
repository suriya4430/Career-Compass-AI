import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Search, TrendingUp, BookOpen, Sparkles, Loader2 } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { SkillCard } from "@/components/dashboard/SkillCard";
import { getAISkillRecommendations, type Profile, type Skill, type AISkillRecommendation } from "@/lib/api";

export default function Skills() {
  const [searchQuery, setSearchQuery] = useState("");

  const { data: profile } = useQuery<Profile | null>({
    queryKey: ["/api/profile"],
  });

  const userSkills = profile?.skills || [];
  const userInterests = profile?.interests || [];

  const { data: allSkills = [], isLoading: skillsLoading } = useQuery<Skill[]>({
    queryKey: ["/api/skills"],
  });

  const { data: recommendedSkills = [], isLoading: recommendedLoading } = useQuery<Skill[]>({
    queryKey: ["/api/skills/recommend", userSkills, userInterests],
    queryFn: async () => {
      const res = await fetch("/api/skills/recommend", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ skills: userSkills, interests: userInterests }),
      });
      return res.json();
    },
  });

  const aiRecommendationsMutation = useMutation({
    mutationFn: () => getAISkillRecommendations(
      userSkills,
      userInterests,
      profile?.experience || undefined,
      profile?.title || undefined
    ),
  });

  const formattedRecommendations = recommendedSkills.map(s => ({
    id: s.id,
    name: s.name,
    category: s.category,
    relevance: s.trending ? "Trending" : "Recommended",
    trending: s.trending || false,
    reason: s.description || "This skill will help advance your career.",
  }));

  const filteredRecommended = formattedRecommendations.filter((skill) =>
    skill.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    skill.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const currentSkillsWithLevel = userSkills.map((name, i) => ({
    name,
    level: Math.max(50, 100 - i * 10),
    category: "Your Skills",
  }));

  const trendingSkills = allSkills
    .filter(s => s.trending)
    .map(s => ({
      name: s.name,
      growth: Math.floor(Math.random() * 30) + 20,
      jobs: Math.floor(Math.random() * 2000) + 500,
    }));

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold" data-testid="text-skills-title">Skills</h1>
        <p className="text-muted-foreground">Track your skills and discover what to learn next.</p>
      </div>

      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          placeholder="Search skills..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10"
          data-testid="input-search-skills"
        />
      </div>

      <Tabs defaultValue="recommended" className="space-y-6">
        <TabsList>
          <TabsTrigger value="recommended" data-testid="tab-recommended-skills">Recommended</TabsTrigger>
          <TabsTrigger value="current" data-testid="tab-current-skills">My Skills</TabsTrigger>
          <TabsTrigger value="trending" data-testid="tab-trending-skills">Trending</TabsTrigger>
          <TabsTrigger value="ai" data-testid="tab-ai-skills">AI Powered</TabsTrigger>
        </TabsList>

        <TabsContent value="recommended" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Skills Gap Analysis</CardTitle>
              <CardDescription>
                Based on your target roles and matched jobs, here are the skills you should focus on.
              </CardDescription>
            </CardHeader>
            <CardContent>
              {recommendedLoading ? (
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  <Skeleton className="h-32" />
                  <Skeleton className="h-32" />
                  <Skeleton className="h-32" />
                </div>
              ) : filteredRecommended.length > 0 ? (
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {filteredRecommended.map((skill) => (
                    <SkillCard
                      key={skill.id}
                      skill={skill}
                      onLearnMore={(s) => console.log("Learn:", s.name)}
                    />
                  ))}
                </div>
              ) : (
                <p className="text-center text-muted-foreground py-8">
                  Add skills to your profile to see recommendations.
                </p>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="current" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Your Skill Profile</CardTitle>
              <CardDescription>
                Skills you've added to your profile with proficiency levels.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {currentSkillsWithLevel.length > 0 ? (
                currentSkillsWithLevel.map((skill, index) => (
                  <div key={index} className="space-y-2" data-testid={`skill-progress-${index}`}>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-sm">{skill.name}</span>
                        <Badge variant="secondary" className="text-xs">{skill.category}</Badge>
                      </div>
                      <span className="text-sm text-muted-foreground">{skill.level}%</span>
                    </div>
                    <Progress value={skill.level} className="h-2" />
                  </div>
                ))
              ) : (
                <p className="text-center text-muted-foreground py-8">
                  No skills added yet. Add skills in your profile.
                </p>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="trending" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-chart-2" />
                Trending Skills in Tech
              </CardTitle>
              <CardDescription>
                Skills with the highest growth in job postings this year.
              </CardDescription>
            </CardHeader>
            <CardContent>
              {skillsLoading ? (
                <div className="space-y-4">
                  <Skeleton className="h-16" />
                  <Skeleton className="h-16" />
                  <Skeleton className="h-16" />
                </div>
              ) : (
                <div className="space-y-4">
                  {trendingSkills.map((skill, index) => (
                    <div
                      key={index}
                      className="flex items-center justify-between p-4 rounded-md border hover-elevate"
                      data-testid={`trending-skill-${index}`}
                    >
                      <div className="flex items-center gap-4">
                        <div className="w-8 h-8 rounded-md bg-chart-2/10 flex items-center justify-center text-chart-2 font-bold text-sm">
                          {index + 1}
                        </div>
                        <div>
                          <p className="font-medium">{skill.name}</p>
                          <p className="text-xs text-muted-foreground">{skill.jobs.toLocaleString()} job postings</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <Badge variant="secondary" className="gap-1">
                          <TrendingUp className="w-3 h-3" />
                          +{skill.growth}%
                        </Badge>
                        <Button size="sm" variant="ghost" data-testid={`button-learn-trending-${index}`}>
                          <BookOpen className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="ai" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-primary" />
                AI-Powered Recommendations
              </CardTitle>
              <CardDescription>
                Get personalized skill recommendations powered by AI based on your profile and career goals.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button
                onClick={() => aiRecommendationsMutation.mutate()}
                disabled={aiRecommendationsMutation.isPending}
                className="gap-2"
                data-testid="button-get-ai-recommendations"
              >
                {aiRecommendationsMutation.isPending ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    Get AI Recommendations
                  </>
                )}
              </Button>

              {aiRecommendationsMutation.data && (
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 mt-4">
                  {aiRecommendationsMutation.data.map((skill) => (
                    <SkillCard
                      key={skill.id}
                      skill={skill}
                      onLearnMore={(s) => console.log("Learn:", s.name)}
                    />
                  ))}
                </div>
              )}

              {aiRecommendationsMutation.isError && (
                <p className="text-destructive text-sm">
                  Failed to get AI recommendations. Please try again.
                </p>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
