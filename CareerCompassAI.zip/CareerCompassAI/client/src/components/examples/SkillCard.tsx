import { SkillCard, Skill } from "../dashboard/SkillCard";

const mockSkill: Skill = {
  id: "1",
  name: "TypeScript",
  category: "Programming Language",
  relevance: "High Demand",
  trending: true,
  reason: "TypeScript is essential for modern web development and is required in 78% of matching jobs.",
};

export default function SkillCardExample() {
  return (
    <div className="max-w-xs">
      <SkillCard skill={mockSkill} onLearnMore={(skill) => console.log("Learn more:", skill.name)} />
    </div>
  );
}
