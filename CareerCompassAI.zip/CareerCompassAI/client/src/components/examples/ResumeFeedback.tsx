import { ResumeFeedback } from "../dashboard/ResumeFeedback";

export default function ResumeFeedbackExample() {
  return (
    <div className="max-w-3xl">
      <ResumeFeedback onAnalyze={(text) => console.log("Analyzing resume:", text.substring(0, 50))} />
    </div>
  );
}
