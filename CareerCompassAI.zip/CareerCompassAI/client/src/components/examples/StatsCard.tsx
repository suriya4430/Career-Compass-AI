import { Briefcase, TrendingUp, Target, Lightbulb } from "lucide-react";
import { StatsCard } from "../dashboard/StatsCard";

export default function StatsCardExample() {
  return (
    <div className="grid grid-cols-2 gap-4 max-w-2xl">
      <StatsCard
        title="Jobs Matched"
        value={24}
        description="Based on your profile"
        icon={Briefcase}
        trend={{ value: 12, isPositive: true }}
        color="chart-1"
      />
      <StatsCard
        title="Profile Strength"
        value="85%"
        description="Complete your profile"
        icon={Target}
        color="chart-2"
      />
      <StatsCard
        title="Skills to Learn"
        value={8}
        description="Recommended for you"
        icon={Lightbulb}
        color="chart-3"
      />
      <StatsCard
        title="Applications"
        value={12}
        description="This month"
        icon={TrendingUp}
        trend={{ value: 5, isPositive: true }}
        color="chart-4"
      />
    </div>
  );
}
