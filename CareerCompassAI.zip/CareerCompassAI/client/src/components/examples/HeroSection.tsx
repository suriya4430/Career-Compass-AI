import { HeroSection } from "../landing/HeroSection";

export default function HeroSectionExample() {
  return <HeroSection />;
}
