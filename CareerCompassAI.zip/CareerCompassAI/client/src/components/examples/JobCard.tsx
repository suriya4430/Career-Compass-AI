import { JobCard, Job } from "../dashboard/JobCard";

const mockJob: Job = {
  id: "1",
  title: "Senior Software Engineer",
  company: "TechCorp",
  location: "San Francisco, CA",
  type: "Full-time",
  salary: "$150K - $200K",
  matchScore: 92,
  skills: ["React", "TypeScript", "Node.js", "AWS", "PostgreSQL"],
  postedAt: "2 days ago",
};

export default function JobCardExample() {
  return (
    <div className="max-w-2xl">
      <JobCard job={mockJob} onViewDetails={(job) => console.log("View details:", job.title)} />
    </div>
  );
}
