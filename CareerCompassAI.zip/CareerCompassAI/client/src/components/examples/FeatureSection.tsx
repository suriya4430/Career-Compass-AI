import { FeatureSection } from "../landing/FeatureSection";

export default function FeatureSectionExample() {
  return <FeatureSection />;
}
