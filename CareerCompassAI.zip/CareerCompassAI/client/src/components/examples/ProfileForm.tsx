import { ProfileForm } from "../dashboard/ProfileForm";

const mockData = {
  name: "John Doe",
  email: "john@example.com",
  title: "Software Engineer",
  experience: "mid",
  education: "bachelor",
  skills: ["JavaScript", "React", "Node.js"],
  interests: ["AI/ML", "FinTech"],
  bio: "Passionate software engineer with 4 years of experience building scalable web applications.",
};

export default function ProfileFormExample() {
  return (
    <div className="max-w-3xl">
      <ProfileForm 
        initialData={mockData} 
        onSave={(data) => console.log("Profile saved:", data)} 
      />
    </div>
  );
}
