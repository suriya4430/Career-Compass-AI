import { useState } from "react";
import { CheckCircle2, AlertCircle, Info, RefreshCw, Sparkles, Upload } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { cn } from "@/lib/utils";

interface FeedbackItem {
  type: "success" | "warning" | "info";
  title: string;
  description: string;
}

interface FeedbackSection {
  title: string;
  items: FeedbackItem[];
}

interface ResumeFeedbackProps {
  onAnalyze?: (resumeText: string) => void;
  isLoading?: boolean;
  feedback?: FeedbackSection[];
}

// todo: remove mock functionality
const mockFeedback: FeedbackSection[] = [
  {
    title: "Content & Impact",
    items: [
      { type: "success", title: "Strong action verbs", description: "You use powerful action verbs like 'developed', 'implemented', and 'led' effectively." },
      { type: "warning", title: "Quantify achievements", description: "Consider adding more specific metrics (e.g., 'increased sales by 25%' instead of 'increased sales')." },
      { type: "info", title: "Add context", description: "Some bullet points could benefit from additional context about the scope or impact of your work." },
    ],
  },
  {
    title: "Format & Structure",
    items: [
      { type: "success", title: "Clear sections", description: "Your resume has well-defined sections that are easy to navigate." },
      { type: "success", title: "Appropriate length", description: "Resume length is appropriate for your experience level." },
      { type: "warning", title: "Consistent formatting", description: "Ensure consistent date formatting throughout (use either 'Jan 2023' or '01/2023', not both)." },
    ],
  },
  {
    title: "Keywords & ATS Optimization",
    items: [
      { type: "success", title: "Industry keywords present", description: "Your resume includes relevant industry keywords that will help with ATS systems." },
      { type: "warning", title: "Missing skills", description: "Consider adding these trending skills if applicable: 'cloud computing', 'agile methodologies', 'data analysis'." },
      { type: "info", title: "Job title alignment", description: "Make sure your job titles align with industry standards to improve searchability." },
    ],
  },
];

export function ResumeFeedback({ onAnalyze, isLoading = false, feedback = mockFeedback }: ResumeFeedbackProps) {
  const [resumeText, setResumeText] = useState("");
  const [hasAnalyzed, setHasAnalyzed] = useState(true); // todo: set to false in production
  const [openSections, setOpenSections] = useState<string[]>(["Content & Impact"]);

  const handleAnalyze = () => {
    if (resumeText.trim()) {
      setHasAnalyzed(true);
      onAnalyze?.(resumeText);
    }
  };

  const toggleSection = (title: string) => {
    setOpenSections(prev => 
      prev.includes(title) 
        ? prev.filter(t => t !== title)
        : [...prev, title]
    );
  };

  const getIcon = (type: FeedbackItem["type"]) => {
    switch (type) {
      case "success":
        return <CheckCircle2 className="w-4 h-4 text-chart-2 shrink-0" />;
      case "warning":
        return <AlertCircle className="w-4 h-4 text-chart-4 shrink-0" />;
      case "info":
        return <Info className="w-4 h-4 text-chart-1 shrink-0" />;
    }
  };

  const getBgColor = (type: FeedbackItem["type"]) => {
    switch (type) {
      case "success":
        return "bg-chart-2/10";
      case "warning":
        return "bg-chart-4/10";
      case "info":
        return "bg-chart-1/10";
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-primary" />
            AI Resume Feedback
          </CardTitle>
          <CardDescription>
            Paste your resume text below to get AI-powered suggestions for improvement.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Textarea
            placeholder="Paste your resume content here... Include your work experience, skills, education, and any other relevant information."
            value={resumeText}
            onChange={(e) => setResumeText(e.target.value)}
            className="min-h-48"
            data-testid="textarea-resume"
          />
          <div className="flex flex-wrap gap-2">
            <Button
              onClick={handleAnalyze}
              disabled={isLoading || !resumeText.trim()}
              className="gap-2"
              data-testid="button-analyze-resume"
            >
              {isLoading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  Analyzing...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  Analyze Resume
                </>
              )}
            </Button>
            <Button variant="outline" className="gap-2" data-testid="button-upload-resume">
              <Upload className="w-4 h-4" />
              Upload PDF
            </Button>
          </div>
        </CardContent>
      </Card>

      {hasAnalyzed && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold">Analysis Results</h3>
            <Button
              variant="ghost"
              size="sm"
              className="gap-2"
              onClick={handleAnalyze}
              disabled={isLoading}
              data-testid="button-regenerate-feedback"
            >
              <RefreshCw className={cn("w-4 h-4", isLoading && "animate-spin")} />
              Regenerate
            </Button>
          </div>

          {feedback.map((section, sectionIndex) => (
            <Card key={sectionIndex} data-testid={`card-feedback-section-${sectionIndex}`}>
              <Collapsible
                open={openSections.includes(section.title)}
                onOpenChange={() => toggleSection(section.title)}
              >
                <CollapsibleTrigger asChild>
                  <CardHeader className="cursor-pointer hover-elevate">
                    <CardTitle className="text-base flex items-center justify-between">
                      {section.title}
                      <span className="text-sm font-normal text-muted-foreground">
                        {section.items.length} suggestions
                      </span>
                    </CardTitle>
                  </CardHeader>
                </CollapsibleTrigger>
                <CollapsibleContent>
                  <CardContent className="pt-0 space-y-3">
                    {section.items.map((item, itemIndex) => (
                      <div
                        key={itemIndex}
                        className={cn("p-3 rounded-md", getBgColor(item.type))}
                        data-testid={`feedback-item-${sectionIndex}-${itemIndex}`}
                      >
                        <div className="flex items-start gap-3">
                          {getIcon(item.type)}
                          <div>
                            <p className="font-medium text-sm">{item.title}</p>
                            <p className="text-sm text-muted-foreground mt-1">{item.description}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </CollapsibleContent>
              </Collapsible>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
