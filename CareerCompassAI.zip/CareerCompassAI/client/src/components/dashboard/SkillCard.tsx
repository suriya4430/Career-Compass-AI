import { TrendingUp, BookOpen, ExternalLink } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

export interface Skill {
  id: string;
  name: string;
  category: string;
  relevance: string;
  trending: boolean;
  reason: string;
}

interface SkillCardProps {
  skill: Skill;
  onLearnMore?: (skill: Skill) => void;
}

export function SkillCard({ skill, onLearnMore }: SkillCardProps) {
  return (
    <Card className="hover-elevate" data-testid={`card-skill-${skill.id}`}>
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-2 mb-2">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-md bg-primary/10 flex items-center justify-center">
              <BookOpen className="w-4 h-4 text-primary" />
            </div>
            <div>
              <h4 className="font-medium text-sm" data-testid={`text-skill-name-${skill.id}`}>{skill.name}</h4>
              <p className="text-xs text-muted-foreground">{skill.category}</p>
            </div>
          </div>
          {skill.trending && (
            <Badge variant="secondary" className="gap-1 text-xs shrink-0">
              <TrendingUp className="w-3 h-3" />
              Trending
            </Badge>
          )}
        </div>
        
        <p className="text-xs text-muted-foreground mb-3 line-clamp-2">{skill.reason}</p>
        
        <div className="flex items-center justify-between gap-2">
          <Badge variant="outline" className="text-xs">{skill.relevance}</Badge>
          <Button 
            variant="ghost" 
            size="sm" 
            className="h-7 text-xs gap-1"
            onClick={() => onLearnMore?.(skill)}
            data-testid={`button-learn-skill-${skill.id}`}
          >
            Learn
            <ExternalLink className="w-3 h-3" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
