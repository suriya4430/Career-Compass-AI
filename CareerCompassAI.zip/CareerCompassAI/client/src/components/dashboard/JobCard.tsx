import { MapPin, Building2, Clock, ExternalLink } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

export interface Job {
  id: string;
  title: string;
  company: string;
  location: string;
  type: string;
  salary: string;
  matchScore: number;
  skills: string[];
  postedAt: string;
}

interface JobCardProps {
  job: Job;
  onViewDetails?: (job: Job) => void;
}

export function JobCard({ job, onViewDetails }: JobCardProps) {
  const getMatchColor = (score: number) => {
    if (score >= 90) return "bg-chart-2 text-white";
    if (score >= 75) return "bg-chart-1 text-white";
    if (score >= 60) return "bg-chart-4 text-white";
    return "bg-muted text-muted-foreground";
  };

  return (
    <Card className="hover-elevate" data-testid={`card-job-${job.id}`}>
      <CardContent className="p-6">
        <div className="flex items-start justify-between gap-4 mb-4">
          <div className="flex-1 min-w-0">
            <h3 className="font-semibold text-lg truncate" data-testid={`text-job-title-${job.id}`}>
              {job.title}
            </h3>
            <div className="flex flex-wrap items-center gap-3 mt-1 text-sm text-muted-foreground">
              <span className="flex items-center gap-1">
                <Building2 className="w-4 h-4" />
                {job.company}
              </span>
              <span className="flex items-center gap-1">
                <MapPin className="w-4 h-4" />
                {job.location}
              </span>
            </div>
          </div>
          <Badge className={`${getMatchColor(job.matchScore)} shrink-0`} data-testid={`badge-match-score-${job.id}`}>
            {job.matchScore}% Match
          </Badge>
        </div>
        
        <div className="flex flex-wrap gap-2 mb-4">
          {job.skills.slice(0, 4).map((skill, index) => (
            <Badge key={index} variant="secondary" className="text-xs">
              {skill}
            </Badge>
          ))}
          {job.skills.length > 4 && (
            <Badge variant="outline" className="text-xs">
              +{job.skills.length - 4} more
            </Badge>
          )}
        </div>
        
        <div className="flex flex-wrap items-center justify-between gap-4 pt-4 border-t">
          <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
            <span>{job.salary}</span>
            <span className="flex items-center gap-1">
              <Clock className="w-3 h-3" />
              {job.postedAt}
            </span>
            <Badge variant="outline" className="text-xs">{job.type}</Badge>
          </div>
          <Button 
            variant="ghost" 
            size="sm" 
            className="gap-1"
            onClick={() => onViewDetails?.(job)}
            data-testid={`button-view-job-${job.id}`}
          >
            View Details
            <ExternalLink className="w-3 h-3" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
