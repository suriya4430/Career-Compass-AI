import { Link } from "wouter";
import { ArrowRight, Sparkles, Target, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";

export function HeroSection() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-primary/5 to-background">
      <div className="max-w-7xl mx-auto px-6 py-20 lg:py-32">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium">
              <Sparkles className="w-4 h-4" />
              <span>AI-Powered Career Guidance</span>
            </div>
            
            <h1 className="text-4xl lg:text-5xl xl:text-6xl font-bold leading-tight" data-testid="text-hero-title">
              Find Your Perfect
              <span className="text-primary block">Career Path</span>
            </h1>
            
            <p className="text-lg text-muted-foreground max-w-lg" data-testid="text-hero-subtitle">
              Get personalized job recommendations, skill improvement suggestions, 
              and AI-powered resume feedback. Accelerate your career with data-driven insights.
            </p>
            
            <div className="flex flex-wrap gap-4">
              <Link href="/profile">
                <Button size="lg" className="gap-2" data-testid="button-hero-get-started">
                  Start Your Journey
                  <ArrowRight className="w-4 h-4" />
                </Button>
              </Link>
              <Link href="/dashboard">
                <Button size="lg" variant="outline" data-testid="button-hero-view-demo">
                  View Dashboard
                </Button>
              </Link>
            </div>
            
            <div className="flex flex-wrap items-center gap-8 pt-4 text-sm text-muted-foreground">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-chart-2" />
                <span data-testid="text-stat-jobs">10,000+ Jobs Matched</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-chart-1" />
                <span data-testid="text-stat-users">5,000+ Users</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-chart-3" />
                <span data-testid="text-stat-skills">500+ Skills Tracked</span>
              </div>
            </div>
          </div>
          
          <div className="relative hidden lg:block">
            <div className="relative bg-card rounded-lg border p-6 shadow-lg">
              <div className="flex items-center justify-between mb-6">
                <h3 className="font-semibold">Your Career Dashboard</h3>
                <span className="text-xs text-muted-foreground">Live Preview</span>
              </div>
              
              <div className="space-y-4">
                <div className="flex items-center gap-4 p-4 bg-background rounded-md border">
                  <div className="w-10 h-10 rounded-md bg-primary/10 flex items-center justify-center">
                    <Target className="w-5 h-5 text-primary" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-sm">Profile Strength</p>
                    <div className="w-full h-2 bg-muted rounded-full mt-1">
                      <div className="w-4/5 h-full bg-chart-2 rounded-full" />
                    </div>
                  </div>
                  <span className="text-sm font-semibold text-chart-2">85%</span>
                </div>
                
                <div className="flex items-center gap-4 p-4 bg-background rounded-md border">
                  <div className="w-10 h-10 rounded-md bg-chart-1/10 flex items-center justify-center">
                    <Briefcase className="w-5 h-5 text-chart-1" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-sm">Jobs Matched</p>
                    <p className="text-xs text-muted-foreground">Based on your profile</p>
                  </div>
                  <span className="text-2xl font-bold">24</span>
                </div>
                
                <div className="flex items-center gap-4 p-4 bg-background rounded-md border">
                  <div className="w-10 h-10 rounded-md bg-chart-3/10 flex items-center justify-center">
                    <TrendingUp className="w-5 h-5 text-chart-3" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-sm">Skills to Learn</p>
                    <p className="text-xs text-muted-foreground">Recommended for you</p>
                  </div>
                  <span className="text-2xl font-bold">8</span>
                </div>
              </div>
            </div>
            
            <div className="absolute -bottom-4 -right-4 w-24 h-24 bg-primary/20 rounded-full blur-3xl" />
            <div className="absolute -top-4 -left-4 w-32 h-32 bg-chart-3/20 rounded-full blur-3xl" />
          </div>
        </div>
      </div>
    </section>
  );
}

function Briefcase(props: { className?: string }) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
      <rect width="20" height="14" x="2" y="7" rx="2" ry="2"/>
      <path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/>
    </svg>
  );
}
