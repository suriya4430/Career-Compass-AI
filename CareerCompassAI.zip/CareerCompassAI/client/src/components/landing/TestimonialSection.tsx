import { Star } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

// todo: remove mock functionality
const testimonials = [
  {
    name: "Sarah Chen",
    role: "Software Engineer at Google",
    initials: "SC",
    content: "CareerAI helped me identify the skills I needed to transition into tech. Within 3 months, I landed my dream job!",
    rating: 5,
  },
  {
    name: "Michael Rodriguez",
    role: "Product Manager at Stripe",
    initials: "MR",
    content: "The AI resume feedback was incredibly detailed. It pointed out things I never would have noticed myself.",
    rating: 5,
  },
  {
    name: "Emily Watson",
    role: "Data Scientist at Netflix",
    initials: "EW",
    content: "The job matching algorithm is spot-on. Every recommendation felt tailored to my specific experience and goals.",
    rating: 5,
  },
];

export function TestimonialSection() {
  return (
    <section id="testimonials" className="py-20 lg:py-32 bg-muted/30">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold mb-4" data-testid="text-testimonials-title">
            Success Stories
          </h2>
          <p className="text-lg text-muted-foreground" data-testid="text-testimonials-subtitle">
            Join thousands of professionals who accelerated their careers with CareerAI.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="hover-elevate" data-testid={`card-testimonial-${index}`}>
              <CardContent className="p-6">
                <div className="flex gap-1 mb-4">
                  {Array.from({ length: testimonial.rating }).map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-chart-4 text-chart-4" />
                  ))}
                </div>
                <p className="text-muted-foreground mb-6">{testimonial.content}</p>
                <div className="flex items-center gap-3">
                  <Avatar>
                    <AvatarFallback className="bg-primary/10 text-primary font-medium">
                      {testimonial.initials}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-medium text-sm">{testimonial.name}</p>
                    <p className="text-xs text-muted-foreground">{testimonial.role}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        
        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
          <div data-testid="stat-jobs-matched">
            <p className="text-3xl lg:text-4xl font-bold text-primary">10K+</p>
            <p className="text-sm text-muted-foreground mt-1">Jobs Matched</p>
          </div>
          <div data-testid="stat-users-helped">
            <p className="text-3xl lg:text-4xl font-bold text-primary">5K+</p>
            <p className="text-sm text-muted-foreground mt-1">Users Helped</p>
          </div>
          <div data-testid="stat-skills-recommended">
            <p className="text-3xl lg:text-4xl font-bold text-primary">500+</p>
            <p className="text-sm text-muted-foreground mt-1">Skills Tracked</p>
          </div>
          <div data-testid="stat-success-rate">
            <p className="text-3xl lg:text-4xl font-bold text-primary">92%</p>
            <p className="text-sm text-muted-foreground mt-1">Success Rate</p>
          </div>
        </div>
      </div>
    </section>
  );
}
