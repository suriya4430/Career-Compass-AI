import { UserPlus, Search, Rocket } from "lucide-react";

const steps = [
  {
    icon: UserPlus,
    step: "01",
    title: "Create Your Profile",
    description: "Enter your skills, education, experience, and career interests. The more details, the better your matches.",
  },
  {
    icon: Search,
    step: "02",
    title: "Get Matched",
    description: "Our AI analyzes thousands of opportunities to find jobs that align with your profile and goals.",
  },
  {
    icon: Rocket,
    step: "03",
    title: "Accelerate Your Career",
    description: "Apply to matched jobs, improve your skills, and get AI feedback on your resume to stand out.",
  },
];

export function HowItWorks() {
  return (
    <section id="how-it-works" className="py-20 lg:py-32">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold mb-4" data-testid="text-how-it-works-title">
            How It Works
          </h2>
          <p className="text-lg text-muted-foreground" data-testid="text-how-it-works-subtitle">
            Three simple steps to transform your job search and career development.
          </p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          {steps.map((step, index) => (
            <div key={index} className="relative" data-testid={`step-${index}`}>
              <div className="flex flex-col items-center text-center">
                <div className="relative mb-6">
                  <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center">
                    <step.icon className="w-8 h-8 text-primary" />
                  </div>
                  <span className="absolute -top-2 -right-2 w-8 h-8 rounded-full bg-primary text-primary-foreground text-sm font-bold flex items-center justify-center">
                    {step.step}
                  </span>
                </div>
                <h3 className="text-xl font-semibold mb-3">{step.title}</h3>
                <p className="text-muted-foreground">{step.description}</p>
              </div>
              
              {index < steps.length - 1 && (
                <div className="hidden md:block absolute top-10 left-[60%] w-[80%] border-t-2 border-dashed border-muted-foreground/30" />
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
