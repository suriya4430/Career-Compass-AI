import { Target, Lightbulb, FileText, TrendingUp, Sparkles, BarChart3 } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const features = [
  {
    icon: Target,
    title: "Smart Job Matching",
    description: "Our algorithm analyzes your skills, experience, and interests to find jobs that truly fit your profile.",
    color: "text-chart-1",
    bgColor: "bg-chart-1/10",
  },
  {
    icon: Lightbulb,
    title: "Skill Recommendations",
    description: "Get personalized suggestions for skills to learn based on your career goals and market trends.",
    color: "text-chart-2",
    bgColor: "bg-chart-2/10",
  },
  {
    icon: FileText,
    title: "AI Resume Feedback",
    description: "Receive detailed, actionable feedback on your resume powered by advanced AI analysis.",
    color: "text-chart-3",
    bgColor: "bg-chart-3/10",
  },
  {
    icon: TrendingUp,
    title: "Career Path Planning",
    description: "Visualize your career progression and discover the steps needed to reach your dream role.",
    color: "text-chart-4",
    bgColor: "bg-chart-4/10",
  },
  {
    icon: Sparkles,
    title: "Personalized Insights",
    description: "Get data-driven insights about your industry, salary expectations, and growth opportunities.",
    color: "text-chart-5",
    bgColor: "bg-chart-5/10",
  },
  {
    icon: BarChart3,
    title: "Progress Tracking",
    description: "Monitor your job applications, skill development, and profile improvements over time.",
    color: "text-primary",
    bgColor: "bg-primary/10",
  },
];

export function FeatureSection() {
  return (
    <section id="features" className="py-20 lg:py-32 bg-muted/30">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold mb-4" data-testid="text-features-title">
            Everything You Need to Accelerate Your Career
          </h2>
          <p className="text-lg text-muted-foreground" data-testid="text-features-subtitle">
            Powerful tools and AI-driven insights to help you land your dream job faster.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <Card key={index} className="hover-elevate" data-testid={`card-feature-${index}`}>
              <CardContent className="p-6">
                <div className={`w-12 h-12 rounded-lg ${feature.bgColor} flex items-center justify-center mb-4`}>
                  <feature.icon className={`w-6 h-6 ${feature.color}`} />
                </div>
                <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
                <p className="text-muted-foreground text-sm">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
