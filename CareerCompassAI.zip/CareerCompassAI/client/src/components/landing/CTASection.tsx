import { Link } from "wouter";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

export function CTASection() {
  return (
    <section className="py-20 lg:py-32">
      <div className="max-w-4xl mx-auto px-6 text-center">
        <h2 className="text-3xl lg:text-4xl font-bold mb-4" data-testid="text-cta-title">
          Ready to Transform Your Career?
        </h2>
        <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto" data-testid="text-cta-subtitle">
          Join thousands of professionals who have accelerated their careers with AI-powered insights 
          and personalized job recommendations.
        </p>
        <div className="flex flex-wrap justify-center gap-4">
          <Link href="/profile">
            <Button size="lg" className="gap-2" data-testid="button-cta-get-started">
              Get Started Free
              <ArrowRight className="w-4 h-4" />
            </Button>
          </Link>
          <Link href="/dashboard">
            <Button size="lg" variant="outline" data-testid="button-cta-view-demo">
              View Demo Dashboard
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
}
