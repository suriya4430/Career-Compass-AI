# AI-Powered Career Assistant

## Overview

CareerAI is an AI-powered career guidance platform that helps professionals find jobs, develop skills, and improve their resumes. The application uses modern web technologies to deliver personalized job recommendations, skill development suggestions, and AI-driven resume feedback. Built as a full-stack TypeScript application, it combines a React frontend with an Express backend, leveraging OpenAI's GPT models for intelligent career insights.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Build Tools**
- **React 18** with TypeScript for type-safe component development
- **Vite** as the build tool and development server for fast hot module replacement
- **Wouter** for lightweight client-side routing (replacing React Router)
- **TanStack Query (React Query)** for server state management, caching, and data fetching

**UI Component System**
- **Shadcn/ui** component library based on Radix UI primitives
- **Tailwind CSS** for utility-first styling with custom design tokens
- Design system inspired by LinkedIn's professional aesthetic and Notion's clean data presentation
- Custom color system using HSL values with CSS variables for theme support
- Typography hierarchy using Inter font family exclusively

**State Management**
- React Query handles all server state (profiles, jobs, skills, AI recommendations)
- Local component state using React hooks for UI interactions
- Form state managed with React Hook Form and Zod validation

**Key Design Patterns**
- Component composition with Radix UI primitives for accessibility
- Responsive design with mobile-first approach (breakpoint at 768px)
- Card-based layouts for scannable content organization
- Hover and active elevation effects for interactive elements

### Backend Architecture

**Server Framework**
- **Express.js** with TypeScript for the REST API
- HTTP server creation using Node's native `http` module
- Request logging middleware for debugging and monitoring
- JSON body parsing with raw body preservation for webhook support

**API Design**
- RESTful endpoints organized by resource type (profiles, jobs, skills, resume feedback)
- POST endpoints for AI-powered operations (job matching, skill recommendations, resume analysis)
- Stateless API design with no authentication currently implemented (uses default user ID)

**Data Storage Strategy**
- **In-Memory Storage** (`MemStorage` class) for development and demo purposes
- Implements `IStorage` interface for easy swapping to persistent storage
- Pre-seeded with sample job listings and skill data
- Database schema defined using Drizzle ORM (PostgreSQL dialect) for future migration

**Database Schema (Defined but not yet connected)**
- `users` - User authentication data
- `profiles` - User career profiles with skills, interests, experience
- `jobs` - Job listings with requirements and skill matching
- `skills` - Skill catalog with categories and trending flags
- Arrays stored as PostgreSQL text[] for skills, requirements, interests

**AI Integration Architecture**
- **OpenAI GPT-4** integration for resume analysis
- Structured JSON responses for consistent AI output parsing
- Resume feedback organized into three sections: Content & Impact, Format & Structure, Keywords & ATS Optimization
- Skill recommendation system (structure defined but implementation incomplete in codebase)

**Algorithm Design**
- Job matching algorithm compares user skills/interests against job requirements
- Match scoring based on skill overlap and interest alignment
- Skill recommendations filter based on user's current skill set and interests

### Project Structure

**Monorepo Layout**
```
/client          - React frontend application
  /src
    /components  - Reusable UI components
    /pages       - Route-level page components
    /lib         - Utilities and API client
/server          - Express backend
/shared          - Shared TypeScript types and schemas
/script          - Build scripts
```

**Build & Deployment**
- Client built with Vite, outputs to `dist/public`
- Server bundled with esbuild, outputs to `dist/index.cjs`
- Development mode uses Vite middleware for HMR
- Production serves static client files from Express
- Selective dependency bundling (allowlist) to reduce cold start times

## External Dependencies

### Core Infrastructure
- **PostgreSQL** (via Neon serverless) - Database provisioned but not actively used in current implementation
- **Drizzle ORM** - Type-safe database toolkit with PostgreSQL dialect
- **OpenAI API** - GPT-4 model for resume analysis and career insights

### Frontend Libraries
- **Radix UI** - Accessible, unstyled component primitives (20+ components)
- **Tailwind CSS** - Utility-first CSS framework
- **TanStack Query** - Async state management
- **React Hook Form** - Form state management
- **Zod** - Schema validation
- **date-fns** - Date manipulation utilities
- **Lucide React** - Icon library

### Development Tools
- **Replit** platform integrations (vite plugins for cartographer, dev banner, runtime error overlay)
- **TypeScript** - Type checking across entire stack
- **ESBuild** - Fast JavaScript bundler for server code
- **Vite** - Frontend build tool and dev server

### Future Integrations (Structure Present)
- Authentication system (passport.js dependencies installed but not implemented)
- Session management (express-session, connect-pg-simple)
- Email notifications (nodemailer)
- File uploads (multer)
- Payment processing (stripe)
- WebSocket support (ws)