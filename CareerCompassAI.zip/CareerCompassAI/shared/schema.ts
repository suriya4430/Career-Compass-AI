import { pgTable, text, varchar, integer, jsonb, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id", { length: 36 }).primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const profiles = pgTable("profiles", {
  id: varchar("id", { length: 36 }).primaryKey(),
  userId: varchar("user_id", { length: 36 }),
  name: text("name").notNull(),
  email: text("email").notNull(),
  title: text("title"),
  experience: text("experience"),
  education: text("education"),
  skills: text("skills").array().default([]),
  interests: text("interests").array().default([]),
  bio: text("bio"),
});

export const jobs = pgTable("jobs", {
  id: varchar("id", { length: 36 }).primaryKey(),
  title: text("title").notNull(),
  company: text("company").notNull(),
  location: text("location").notNull(),
  type: text("type").notNull(),
  salary: text("salary"),
  description: text("description"),
  requirements: text("requirements").array().default([]),
  skills: text("skills").array().default([]),
  postedAt: text("posted_at"),
});

export const skills = pgTable("skills", {
  id: varchar("id", { length: 36 }).primaryKey(),
  name: text("name").notNull(),
  category: text("category").notNull(),
  description: text("description"),
  trending: boolean("trending").default(false),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertProfileSchema = createInsertSchema(profiles).omit({
  id: true,
});

export const insertJobSchema = createInsertSchema(jobs).omit({
  id: true,
});

export const insertSkillSchema = createInsertSchema(skills).omit({
  id: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertProfile = z.infer<typeof insertProfileSchema>;
export type Profile = typeof profiles.$inferSelect;

export type InsertJob = z.infer<typeof insertJobSchema>;
export type Job = typeof jobs.$inferSelect;

export type InsertSkill = z.infer<typeof insertSkillSchema>;
export type Skill = typeof skills.$inferSelect;

export const resumeFeedbackSchema = z.object({
  resumeText: z.string().min(50, "Resume must be at least 50 characters"),
});

export type ResumeFeedbackRequest = z.infer<typeof resumeFeedbackSchema>;

export const skillRecommendationSchema = z.object({
  skills: z.array(z.string()),
  interests: z.array(z.string()),
  experience: z.string().optional(),
  targetRole: z.string().optional(),
});

export type SkillRecommendationRequest = z.infer<typeof skillRecommendationSchema>;
