import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertProfileSchema, 
  resumeFeedbackSchema, 
  skillRecommendationSchema 
} from "@shared/schema";
import { analyzeResume, getAISkillRecommendations } from "./openai";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // Profile routes
  app.get("/api/profile", async (req, res) => {
    try {
      const profiles = await Promise.all(
        Array.from({ length: 1 }, () => storage.getProfileByUserId("default"))
      );
      const profile = profiles[0];
      if (!profile) {
        return res.json(null);
      }
      res.json(profile);
    } catch (error) {
      console.error("Error fetching profile:", error);
      res.status(500).json({ error: "Failed to fetch profile" });
    }
  });

  app.get("/api/profile/:id", async (req, res) => {
    try {
      const profile = await storage.getProfile(req.params.id);
      if (!profile) {
        return res.status(404).json({ error: "Profile not found" });
      }
      res.json(profile);
    } catch (error) {
      console.error("Error fetching profile:", error);
      res.status(500).json({ error: "Failed to fetch profile" });
    }
  });

  app.post("/api/profile", async (req, res) => {
    try {
      const validated = insertProfileSchema.parse(req.body);
      const profile = await storage.createProfile(validated);
      res.status(201).json(profile);
    } catch (error) {
      console.error("Error creating profile:", error);
      res.status(400).json({ error: "Invalid profile data" });
    }
  });

  app.patch("/api/profile/:id", async (req, res) => {
    try {
      const profile = await storage.updateProfile(req.params.id, req.body);
      if (!profile) {
        return res.status(404).json({ error: "Profile not found" });
      }
      res.json(profile);
    } catch (error) {
      console.error("Error updating profile:", error);
      res.status(500).json({ error: "Failed to update profile" });
    }
  });

  // Jobs routes
  app.get("/api/jobs", async (req, res) => {
    try {
      const jobs = await storage.getAllJobs();
      res.json(jobs);
    } catch (error) {
      console.error("Error fetching jobs:", error);
      res.status(500).json({ error: "Failed to fetch jobs" });
    }
  });

  app.get("/api/jobs/:id", async (req, res) => {
    try {
      const job = await storage.getJob(req.params.id);
      if (!job) {
        return res.status(404).json({ error: "Job not found" });
      }
      res.json(job);
    } catch (error) {
      console.error("Error fetching job:", error);
      res.status(500).json({ error: "Failed to fetch job" });
    }
  });

  app.post("/api/jobs/match", async (req, res) => {
    try {
      const { skills = [], interests = [] } = req.body;
      const matchedJobs = await storage.getMatchedJobs(skills, interests);
      res.json(matchedJobs);
    } catch (error) {
      console.error("Error matching jobs:", error);
      res.status(500).json({ error: "Failed to match jobs" });
    }
  });

  // Skills routes
  app.get("/api/skills", async (req, res) => {
    try {
      const skills = await storage.getAllSkills();
      res.json(skills);
    } catch (error) {
      console.error("Error fetching skills:", error);
      res.status(500).json({ error: "Failed to fetch skills" });
    }
  });

  app.post("/api/skills/recommend", async (req, res) => {
    try {
      const { skills = [], interests = [] } = req.body;
      const recommended = await storage.getRecommendedSkills(skills, interests);
      res.json(recommended);
    } catch (error) {
      console.error("Error recommending skills:", error);
      res.status(500).json({ error: "Failed to recommend skills" });
    }
  });

  // AI-powered routes
  app.post("/api/ai/resume-feedback", async (req, res) => {
    try {
      const validated = resumeFeedbackSchema.parse(req.body);
      const feedback = await analyzeResume(validated.resumeText);
      res.json(feedback);
    } catch (error) {
      console.error("Error analyzing resume:", error);
      res.status(400).json({ error: "Failed to analyze resume" });
    }
  });

  app.post("/api/ai/skill-recommendations", async (req, res) => {
    try {
      const validated = skillRecommendationSchema.parse(req.body);
      const recommendations = await getAISkillRecommendations(
        validated.skills,
        validated.interests,
        validated.experience,
        validated.targetRole
      );
      res.json(recommendations);
    } catch (error) {
      console.error("Error getting AI skill recommendations:", error);
      res.status(400).json({ error: "Failed to get skill recommendations" });
    }
  });

  // Dashboard stats
  app.get("/api/stats", async (req, res) => {
    try {
      const { skills = [], interests = [] } = req.query;
      const userSkills = typeof skills === 'string' ? skills.split(',').filter(Boolean) : [];
      const userInterests = typeof interests === 'string' ? interests.split(',').filter(Boolean) : [];
      
      const matchedJobs = await storage.getMatchedJobs(userSkills, userInterests);
      const recommendedSkills = await storage.getRecommendedSkills(userSkills, userInterests);
      
      const profileStrength = Math.min(100, 
        (userSkills.length > 0 ? 30 : 0) + 
        (userInterests.length > 0 ? 20 : 0) + 
        35 // base profile info
      );
      
      res.json({
        jobsMatched: matchedJobs.length,
        skillsToLearn: recommendedSkills.length,
        profileStrength,
        applications: 0,
      });
    } catch (error) {
      console.error("Error fetching stats:", error);
      res.status(500).json({ error: "Failed to fetch stats" });
    }
  });

  return httpServer;
}
