import OpenAI from "openai";

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

export interface ResumeFeedbackSection {
  title: string;
  items: Array<{
    type: "success" | "warning" | "info";
    title: string;
    description: string;
  }>;
}

export async function analyzeResume(resumeText: string): Promise<ResumeFeedbackSection[]> {
  const response = await openai.chat.completions.create({
    model: "gpt-4o",
    messages: [
      {
        role: "system",
        content: `You are an expert career coach and resume reviewer. Analyze the provided resume and give actionable feedback.
        
Return your analysis as a JSON array with exactly 3 sections:
1. "Content & Impact" - Feedback on action verbs, achievements, quantification
2. "Format & Structure" - Feedback on organization, consistency, length
3. "Keywords & ATS Optimization" - Feedback on industry keywords, job title alignment

Each section should have 2-4 items. Each item has:
- type: "success" (something done well), "warning" (needs improvement), or "info" (general suggestion)
- title: Brief 3-5 word title
- description: 1-2 sentence explanation

Return ONLY valid JSON, no markdown or explanation.`
      },
      {
        role: "user",
        content: `Please analyze this resume and provide feedback:\n\n${resumeText}`
      }
    ],
    temperature: 0.7,
    max_tokens: 1500,
  });

  const content = response.choices[0]?.message?.content || "[]";
  
  try {
    const cleanContent = content.replace(/```json\n?|\n?```/g, '').trim();
    return JSON.parse(cleanContent);
  } catch {
    return [
      {
        title: "Content & Impact",
        items: [
          { type: "info", title: "Analysis complete", description: "Your resume has been reviewed. Consider adding more quantifiable achievements." }
        ]
      },
      {
        title: "Format & Structure",
        items: [
          { type: "success", title: "Good structure", description: "Your resume appears to have a clear structure." }
        ]
      },
      {
        title: "Keywords & ATS Optimization",
        items: [
          { type: "info", title: "Add keywords", description: "Ensure your resume includes relevant industry keywords." }
        ]
      }
    ];
  }
}

export interface SkillRecommendation {
  id: string;
  name: string;
  category: string;
  relevance: string;
  trending: boolean;
  reason: string;
}

export async function getAISkillRecommendations(
  currentSkills: string[],
  interests: string[],
  experience?: string,
  targetRole?: string
): Promise<SkillRecommendation[]> {
  const response = await openai.chat.completions.create({
    model: "gpt-4o",
    messages: [
      {
        role: "system",
        content: `You are a career advisor specializing in tech skills. Based on someone's current skills and career interests, recommend skills they should learn.

Return a JSON array of 4-6 skill recommendations. Each skill should have:
- id: unique string id (use lowercase with dashes)
- name: skill name
- category: one of "Programming", "Frontend", "Backend", "Cloud", "DevOps", "AI/ML", "Database", "API", "Architecture", "Tools"
- relevance: one of "High Demand", "Career Boost", "Senior Level", "Trending", "Essential"
- trending: boolean (is this skill trending in job market)
- reason: 1 sentence explaining why this skill is recommended for them

Return ONLY valid JSON, no markdown or explanation.`
      },
      {
        role: "user",
        content: `Current skills: ${currentSkills.join(", ") || "None specified"}
Interests: ${interests.join(", ") || "General tech"}
Experience level: ${experience || "Not specified"}
Target role: ${targetRole || "Not specified"}

What skills should this person learn next?`
      }
    ],
    temperature: 0.7,
    max_tokens: 1000,
  });

  const content = response.choices[0]?.message?.content || "[]";
  
  try {
    const cleanContent = content.replace(/```json\n?|\n?```/g, '').trim();
    return JSON.parse(cleanContent);
  } catch {
    return [
      { id: "typescript", name: "TypeScript", category: "Programming", relevance: "High Demand", trending: true, reason: "Essential for modern web development and improves code quality." },
      { id: "aws", name: "AWS", category: "Cloud", relevance: "Career Boost", trending: true, reason: "Cloud skills are in high demand and can increase salary by 20%." },
    ];
  }
}

export async function getJobMatchInsights(
  userSkills: string[],
  jobTitle: string,
  jobSkills: string[]
): Promise<string> {
  const response = await openai.chat.completions.create({
    model: "gpt-4o",
    messages: [
      {
        role: "system",
        content: "You are a career advisor. Given a user's skills and a job listing, provide a brief 2-3 sentence insight about the match quality and what skills they might want to develop."
      },
      {
        role: "user",
        content: `User skills: ${userSkills.join(", ")}
Job title: ${jobTitle}
Required skills: ${jobSkills.join(", ")}

Provide a brief insight about this job match.`
      }
    ],
    temperature: 0.7,
    max_tokens: 200,
  });

  return response.choices[0]?.message?.content || "This job appears to be a good match based on your skills.";
}
