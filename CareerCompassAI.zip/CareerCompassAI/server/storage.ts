import { 
  type User, type InsertUser, 
  type Profile, type InsertProfile,
  type Job, type InsertJob,
  type Skill, type InsertSkill
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getProfile(id: string): Promise<Profile | undefined>;
  getProfileByUserId(userId: string): Promise<Profile | undefined>;
  createProfile(profile: InsertProfile): Promise<Profile>;
  updateProfile(id: string, profile: Partial<InsertProfile>): Promise<Profile | undefined>;
  
  getAllJobs(): Promise<Job[]>;
  getJob(id: string): Promise<Job | undefined>;
  createJob(job: InsertJob): Promise<Job>;
  getMatchedJobs(skills: string[], interests: string[]): Promise<Array<Job & { matchScore: number }>>;
  
  getAllSkills(): Promise<Skill[]>;
  getSkill(id: string): Promise<Skill | undefined>;
  createSkill(skill: InsertSkill): Promise<Skill>;
  getRecommendedSkills(userSkills: string[], interests: string[]): Promise<Skill[]>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private profiles: Map<string, Profile>;
  private jobs: Map<string, Job>;
  private skills: Map<string, Skill>;

  constructor() {
    this.users = new Map();
    this.profiles = new Map();
    this.jobs = new Map();
    this.skills = new Map();
    
    this.seedData();
  }

  private seedData() {
    const jobsData: InsertJob[] = [
      {
        title: "Senior Software Engineer",
        company: "TechCorp",
        location: "San Francisco, CA",
        type: "Full-time",
        salary: "$150K - $200K",
        description: "Lead development of scalable web applications using modern technologies.",
        requirements: ["5+ years experience", "CS degree preferred", "Leadership experience"],
        skills: ["React", "TypeScript", "Node.js", "AWS", "PostgreSQL"],
        postedAt: "2 days ago",
      },
      {
        title: "Full Stack Developer",
        company: "StartupXYZ",
        location: "Remote",
        type: "Full-time",
        salary: "$120K - $160K",
        description: "Build and maintain full-stack applications in a fast-paced startup environment.",
        requirements: ["3+ years experience", "Startup experience a plus"],
        skills: ["React", "Python", "PostgreSQL", "Docker", "GraphQL"],
        postedAt: "1 week ago",
      },
      {
        title: "Frontend Engineer",
        company: "DesignCo",
        location: "New York, NY",
        type: "Full-time",
        salary: "$130K - $170K",
        description: "Create beautiful, responsive user interfaces for our design platform.",
        requirements: ["3+ years frontend experience", "Strong CSS skills"],
        skills: ["React", "Vue.js", "CSS", "Figma", "TypeScript"],
        postedAt: "3 days ago",
      },
      {
        title: "Backend Developer",
        company: "DataFlow Inc",
        location: "Austin, TX",
        type: "Full-time",
        salary: "$140K - $180K",
        description: "Design and implement robust backend systems for data processing.",
        requirements: ["4+ years backend experience", "Database expertise"],
        skills: ["Python", "Django", "PostgreSQL", "Redis", "Kubernetes"],
        postedAt: "5 days ago",
      },
      {
        title: "DevOps Engineer",
        company: "CloudScale",
        location: "Remote",
        type: "Full-time",
        salary: "$145K - $185K",
        description: "Manage cloud infrastructure and CI/CD pipelines.",
        requirements: ["3+ years DevOps experience", "Cloud certifications preferred"],
        skills: ["Kubernetes", "AWS", "Terraform", "Docker", "Jenkins"],
        postedAt: "1 week ago",
      },
      {
        title: "React Developer",
        company: "WebAgency",
        location: "Los Angeles, CA",
        type: "Contract",
        salary: "$80/hr - $100/hr",
        description: "Develop React applications for various client projects.",
        requirements: ["2+ years React experience"],
        skills: ["React", "Redux", "TypeScript", "GraphQL", "Jest"],
        postedAt: "4 days ago",
      },
      {
        title: "Machine Learning Engineer",
        company: "AI Labs",
        location: "Seattle, WA",
        type: "Full-time",
        salary: "$160K - $220K",
        description: "Develop and deploy machine learning models at scale.",
        requirements: ["MS/PhD in ML or related field", "Production ML experience"],
        skills: ["Python", "TensorFlow", "PyTorch", "AWS", "Kubernetes"],
        postedAt: "1 day ago",
      },
      {
        title: "Product Manager - Technical",
        company: "SaaS Platform",
        location: "Remote",
        type: "Full-time",
        salary: "$140K - $180K",
        description: "Lead product development for our B2B SaaS platform.",
        requirements: ["5+ years PM experience", "Technical background preferred"],
        skills: ["Product Strategy", "Agile", "SQL", "Data Analysis", "Roadmapping"],
        postedAt: "6 days ago",
      },
    ];

    jobsData.forEach(job => {
      const id = randomUUID();
      const fullJob: Job = {
        id,
        title: job.title,
        company: job.company,
        location: job.location,
        type: job.type,
        salary: job.salary ?? null,
        description: job.description ?? null,
        requirements: job.requirements ?? null,
        skills: job.skills ?? null,
        postedAt: job.postedAt ?? null,
      };
      this.jobs.set(id, fullJob);
    });

    const skillsData: InsertSkill[] = [
      { name: "TypeScript", category: "Programming", description: "Strongly typed JavaScript for scalable applications", trending: true },
      { name: "React", category: "Frontend", description: "Popular UI library for building interactive interfaces", trending: true },
      { name: "Node.js", category: "Backend", description: "JavaScript runtime for server-side development", trending: true },
      { name: "Python", category: "Programming", description: "Versatile language for web, data, and ML", trending: true },
      { name: "AWS", category: "Cloud", description: "Leading cloud platform with comprehensive services", trending: true },
      { name: "Kubernetes", category: "DevOps", description: "Container orchestration for scalable deployments", trending: true },
      { name: "GraphQL", category: "API", description: "Modern API query language", trending: true },
      { name: "PostgreSQL", category: "Database", description: "Advanced open-source relational database", trending: false },
      { name: "Docker", category: "DevOps", description: "Containerization platform", trending: true },
      { name: "System Design", category: "Architecture", description: "Designing scalable distributed systems", trending: false },
      { name: "Machine Learning", category: "AI/ML", description: "Building intelligent systems with data", trending: true },
      { name: "Go", category: "Programming", description: "Fast, efficient language for backend services", trending: true },
      { name: "Rust", category: "Programming", description: "Memory-safe systems programming language", trending: true },
      { name: "Redis", category: "Database", description: "In-memory data store for caching", trending: false },
      { name: "Terraform", category: "DevOps", description: "Infrastructure as code tool", trending: true },
    ];

    skillsData.forEach(skill => {
      const id = randomUUID();
      const fullSkill: Skill = {
        id,
        name: skill.name,
        category: skill.category,
        description: skill.description ?? null,
        trending: skill.trending ?? null,
      };
      this.skills.set(id, fullSkill);
    });
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getProfile(id: string): Promise<Profile | undefined> {
    return this.profiles.get(id);
  }

  async getProfileByUserId(userId: string): Promise<Profile | undefined> {
    return Array.from(this.profiles.values()).find(
      (profile) => profile.userId === userId,
    );
  }

  async createProfile(insertProfile: InsertProfile): Promise<Profile> {
    const id = randomUUID();
    const profile: Profile = { 
      id,
      userId: insertProfile.userId ?? null,
      name: insertProfile.name,
      email: insertProfile.email,
      title: insertProfile.title ?? null,
      experience: insertProfile.experience ?? null,
      education: insertProfile.education ?? null,
      skills: insertProfile.skills ?? null,
      interests: insertProfile.interests ?? null,
      bio: insertProfile.bio ?? null,
    };
    this.profiles.set(id, profile);
    return profile;
  }

  async updateProfile(id: string, updates: Partial<InsertProfile>): Promise<Profile | undefined> {
    const existing = this.profiles.get(id);
    if (!existing) return undefined;
    
    const updated: Profile = { ...existing, ...updates };
    this.profiles.set(id, updated);
    return updated;
  }

  async getAllJobs(): Promise<Job[]> {
    return Array.from(this.jobs.values());
  }

  async getJob(id: string): Promise<Job | undefined> {
    return this.jobs.get(id);
  }

  async createJob(insertJob: InsertJob): Promise<Job> {
    const id = randomUUID();
    const job: Job = { 
      id,
      title: insertJob.title,
      company: insertJob.company,
      location: insertJob.location,
      type: insertJob.type,
      salary: insertJob.salary ?? null,
      description: insertJob.description ?? null,
      requirements: insertJob.requirements ?? null,
      skills: insertJob.skills ?? null,
      postedAt: insertJob.postedAt ?? null,
    };
    this.jobs.set(id, job);
    return job;
  }

  async getMatchedJobs(userSkills: string[], interests: string[]): Promise<Array<Job & { matchScore: number }>> {
    const jobs = Array.from(this.jobs.values());
    const userSkillsLower = userSkills.map(s => s.toLowerCase());
    const interestsLower = interests.map(i => i.toLowerCase());

    const scoredJobs = jobs.map(job => {
      const jobSkills = (job.skills || []).map(s => s.toLowerCase());
      
      const skillMatches = jobSkills.filter(skill => 
        userSkillsLower.some(userSkill => 
          skill.includes(userSkill) || userSkill.includes(skill)
        )
      ).length;
      
      const skillScore = jobSkills.length > 0 
        ? (skillMatches / jobSkills.length) * 70 
        : 30;
      
      const titleLower = job.title.toLowerCase();
      const descLower = (job.description || '').toLowerCase();
      const interestScore = interestsLower.some(interest => 
        titleLower.includes(interest) || descLower.includes(interest)
      ) ? 20 : 0;

      const baseScore = 10;
      const matchScore = Math.min(100, Math.round(skillScore + interestScore + baseScore));

      return { ...job, matchScore };
    });

    return scoredJobs
      .filter(job => job.matchScore >= 50)
      .sort((a, b) => b.matchScore - a.matchScore);
  }

  async getAllSkills(): Promise<Skill[]> {
    return Array.from(this.skills.values());
  }

  async getSkill(id: string): Promise<Skill | undefined> {
    return this.skills.get(id);
  }

  async createSkill(insertSkill: InsertSkill): Promise<Skill> {
    const id = randomUUID();
    const skill: Skill = { 
      id,
      name: insertSkill.name,
      category: insertSkill.category,
      description: insertSkill.description ?? null,
      trending: insertSkill.trending ?? null,
    };
    this.skills.set(id, skill);
    return skill;
  }

  async getRecommendedSkills(userSkills: string[], interests: string[]): Promise<Skill[]> {
    const allSkills = Array.from(this.skills.values());
    const userSkillsLower = userSkills.map(s => s.toLowerCase());
    
    return allSkills.filter(skill => 
      !userSkillsLower.includes(skill.name.toLowerCase())
    ).sort((a, b) => {
      if (a.trending && !b.trending) return -1;
      if (!a.trending && b.trending) return 1;
      return 0;
    }).slice(0, 8);
  }
}

export const storage = new MemStorage();
